class Idea < ApplicationRecord
  belongs_to :category
end
